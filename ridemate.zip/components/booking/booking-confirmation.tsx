"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle2, MapPin, Calendar, Clock, Users, Car } from "lucide-react"
import Link from "next/link"
import type { BookedRide } from "@/lib/storage"
import MockMapPreview from "@/components/map/mock-map-preview"

interface BookingConfirmationProps {
  booking: BookedRide
}

export default function BookingConfirmation({ booking }: BookingConfirmationProps) {
  const [showDetails, setShowDetails] = useState(false)

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center pb-2">
        <div className="flex justify-center mb-4">
          <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center">
            <CheckCircle2 className="h-8 w-8 text-green-600" />
          </div>
        </div>
        <CardTitle className="text-2xl">Booking Confirmed!</CardTitle>
        <CardDescription>Your ride has been successfully booked</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <MockMapPreview
          startLocation={booking.startLocation}
          endLocation={booking.endLocation}
          className="mb-4"
          onClick={() => setShowDetails(!showDetails)}
        />

        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <MapPin className="h-5 w-5 text-muted-foreground mt-0.5 shrink-0" />
            <div>
              <p className="font-medium">From</p>
              <p className="text-sm text-muted-foreground">{booking.startLocation}</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <MapPin className="h-5 w-5 text-muted-foreground mt-0.5 shrink-0" />
            <div>
              <p className="font-medium">To</p>
              <p className="text-sm text-muted-foreground">{booking.endLocation}</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-muted-foreground shrink-0" />
            <div>
              <p className="text-sm font-medium">Date</p>
              <p className="text-sm text-muted-foreground">{booking.date}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-muted-foreground shrink-0" />
            <div>
              <p className="text-sm font-medium">Time</p>
              <p className="text-sm text-muted-foreground">{booking.time}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Users className="h-5 w-5 text-muted-foreground shrink-0" />
            <div>
              <p className="text-sm font-medium">Seats</p>
              <p className="text-sm text-muted-foreground">{booking.seats}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Car className="h-5 w-5 text-muted-foreground shrink-0" />
            <div>
              <p className="text-sm font-medium">Car</p>
              <p className="text-sm text-muted-foreground">{booking.carType}</p>
            </div>
          </div>
        </div>

        <div className="border-t pt-3 mt-3">
          <div className="flex justify-between">
            <span className="font-medium">Total paid:</span>
            <span className="font-bold">₹{booking.totalAmount.toFixed(2)}</span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">Booking ID: {booking.id}</p>
        </div>
      </CardContent>
      <CardFooter className="flex flex-col gap-2">
        <Link href="/my-rides" className="w-full">
          <Button className="w-full">View My Rides</Button>
        </Link>
        <Link href="/" className="w-full">
          <Button variant="outline" className="w-full">
            Back to Home
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}
