"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { MinusCircle, PlusCircle } from "lucide-react"

interface SeatSelectionProps {
  availableSeats: number
  price: number
  onSeatChange: (seats: number) => void
}

export default function SeatSelection({ availableSeats, price, onSeatChange }: SeatSelectionProps) {
  const [selectedSeats, setSelectedSeats] = useState(1)

  const handleSeatChange = (seats: number) => {
    if (seats >= 1 && seats <= availableSeats) {
      setSelectedSeats(seats)
      onSeatChange(seats)
    }
  }

  return (
    <div className="space-y-4">
      <div>
        <Label className="text-base font-medium">Number of Seats</Label>
        <div className="flex items-center justify-between mt-2 border rounded-md p-3">
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={() => handleSeatChange(selectedSeats - 1)}
            disabled={selectedSeats <= 1}
          >
            <MinusCircle className="h-5 w-5" />
            <span className="sr-only">Decrease</span>
          </Button>
          <span className="text-lg font-medium">{selectedSeats}</span>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={() => handleSeatChange(selectedSeats + 1)}
            disabled={selectedSeats >= availableSeats}
          >
            <PlusCircle className="h-5 w-5" />
            <span className="sr-only">Increase</span>
          </Button>
        </div>
        <p className="text-sm text-muted-foreground mt-1">
          {availableSeats} seat{availableSeats !== 1 ? "s" : ""} available
        </p>
      </div>

      <div>
        <Label className="text-base font-medium">Payment Method</Label>
        <RadioGroup defaultValue="card" className="mt-2 grid grid-cols-2 gap-2">
          <div className="flex items-center space-x-2 border rounded-md p-3">
            <RadioGroupItem value="card" id="payment-card" />
            <Label htmlFor="payment-card" className="cursor-pointer">
              Credit/Debit Card
            </Label>
          </div>
          <div className="flex items-center space-x-2 border rounded-md p-3">
            <RadioGroupItem value="upi" id="payment-upi" />
            <Label htmlFor="payment-upi" className="cursor-pointer">
              UPI
            </Label>
          </div>
        </RadioGroup>
      </div>

      <div className="border-t pt-4 mt-4">
        <div className="flex justify-between">
          <span>Price per seat:</span>
          <span>₹{price.toFixed(2)}</span>
        </div>
        <div className="flex justify-between mt-1">
          <span>Seats:</span>
          <span>{selectedSeats}</span>
        </div>
        <div className="flex justify-between mt-1">
          <span>Subtotal:</span>
          <span>₹{(price * selectedSeats).toFixed(2)}</span>
        </div>
        <div className="flex justify-between mt-1">
          <span>Service fee:</span>
          <span>₹50.00</span>
        </div>
        <div className="flex justify-between font-bold mt-2 pt-2 border-t">
          <span>Total:</span>
          <span>₹{(price * selectedSeats + 50).toFixed(2)}</span>
        </div>
      </div>
    </div>
  )
}
