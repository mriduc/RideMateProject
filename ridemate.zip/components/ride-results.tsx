"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { Calendar, Clock, DollarSign, MapPin, Star, ThumbsUp, Users, User } from "lucide-react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import SeatSelection from "@/components/booking/seat-selection"
import { useRouter } from "next/navigation"
import { type BookedRide, generateBookingId, saveBookedRide } from "@/lib/storage"

interface RideResultsProps {
  startLocation: string
  endLocation: string
  date: Date
}

export default function RideResults({ startLocation, endLocation, date }: RideResultsProps) {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("all")
  const [bookingDialogOpen, setBookingDialogOpen] = useState(false)
  const [selectedRide, setSelectedRide] = useState<any | null>(null)
  const [selectedSeats, setSelectedSeats] = useState(1)

  // Mock data for ride results
  const rides = [
    {
      id: 1,
      driver: {
        name: "Alex Johnson",
        rating: 4.8,
        trips: 124,
      },
      startLocation,
      endLocation,
      date: format(date, "PPP"),
      time: "8:00 AM",
      price: 450,
      availableSeats: 3,
      carType: "Maruti Dzire",
      verified: true,
    },
    {
      id: 2,
      driver: {
        name: "Maria Garcia",
        rating: 4.9,
        trips: 86,
      },
      startLocation,
      endLocation,
      date: format(date, "PPP"),
      time: "9:30 AM",
      price: 550,
      availableSeats: 2,
      carType: "Honda Amaze",
      verified: true,
    },
    {
      id: 3,
      driver: {
        name: "David Kim",
        rating: 4.7,
        trips: 52,
      },
      startLocation,
      endLocation,
      date: format(date, "PPP"),
      time: "11:15 AM",
      price: 380,
      availableSeats: 4,
      carType: "Maruti WagonR",
      verified: false,
    },
  ]

  const filteredRides =
    activeTab === "all"
      ? rides
      : rides.filter((ride) => (activeTab === "morning" ? ride.time.includes("AM") : ride.time.includes("PM")))

  const handleBookRide = (ride: any) => {
    setSelectedRide(ride)
    setBookingDialogOpen(true)
  }

  const handleSeatChange = (seats: number) => {
    setSelectedSeats(seats)
  }

  const handleConfirmBooking = () => {
    if (!selectedRide) return

    const serviceFee = 50
    const totalAmount = selectedRide.price * selectedSeats + serviceFee

    // Create booking object
    const booking: BookedRide = {
      id: generateBookingId(),
      rideId: selectedRide.id,
      driverName: selectedRide.driver.name,
      driverRating: selectedRide.driver.rating,
      startLocation: selectedRide.startLocation,
      endLocation: selectedRide.endLocation,
      date: selectedRide.date,
      time: selectedRide.time,
      price: selectedRide.price,
      seats: selectedSeats,
      totalAmount,
      status: "confirmed",
      bookingDate: format(new Date(), "PPP"),
      carType: selectedRide.carType,
    }

    // Save to local storage
    saveBookedRide(booking)

    // Close dialog and redirect to confirmation page
    setBookingDialogOpen(false)
    router.push(`/booking-confirmation?id=${booking.id}`)
  }

  return (
    <div className="mt-8">
      <h2 className="text-2xl font-bold mb-4">Available Rides</h2>
      <Tabs defaultValue="all" className="mb-6" onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">All Times</TabsTrigger>
          <TabsTrigger value="morning">Morning</TabsTrigger>
          <TabsTrigger value="afternoon">Afternoon</TabsTrigger>
        </TabsList>
      </Tabs>

      {filteredRides.length > 0 ? (
        <div className="space-y-4">
          {filteredRides.map((ride) => (
            <Card key={ride.id} className="overflow-hidden">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row gap-6">
                  <div className="flex flex-col items-center md:w-1/4">
                    <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center mb-2">
                      <User className="h-6 w-6 text-green-600" />
                    </div>
                    <h3 className="font-medium text-center">{ride.driver.name}</h3>
                    <div className="flex items-center gap-1 text-amber-500">
                      <Star className="h-4 w-4 fill-current" />
                      <span>{ride.driver.rating}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">{ride.driver.trips} trips</span>
                    {ride.verified && (
                      <Badge variant="outline" className="mt-2 text-xs">
                        <ThumbsUp className="h-3 w-3 mr-1" /> Verified
                      </Badge>
                    )}
                  </div>

                  <div className="flex-1 space-y-4">
                    <div className="grid gap-2">
                      <div className="flex items-start gap-2">
                        <MapPin className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                        <div>
                          <p className="font-medium">{ride.startLocation}</p>
                          <p className="text-sm text-muted-foreground">Pickup point</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <MapPin className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                        <div>
                          <p className="font-medium">{ride.endLocation}</p>
                          <p className="text-sm text-muted-foreground">Drop-off point</p>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-4">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-5 w-5 text-muted-foreground" />
                        <span>{ride.date}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-5 w-5 text-muted-foreground" />
                        <span>{ride.time}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="h-5 w-5 text-muted-foreground" />
                        <span>{ride.availableSeats} seats available</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <DollarSign className="h-5 w-5 text-muted-foreground" />
                        <span className="font-medium">₹{ride.price} per seat</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="bg-muted/50 px-6 py-3 flex justify-between">
                <p className="text-sm">{ride.carType}</p>
                <Button onClick={() => handleBookRide(ride)}>Book Seat</Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground">No rides available for the selected time.</p>
          </CardContent>
        </Card>
      )}

      {/* Booking Dialog */}
      <Dialog open={bookingDialogOpen} onOpenChange={setBookingDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Book Your Ride</DialogTitle>
            <DialogDescription>
              {selectedRide && (
                <>
                  You're booking a ride with {selectedRide.driver.name} from {selectedRide.startLocation} to{" "}
                  {selectedRide.endLocation} on {selectedRide.date} at {selectedRide.time}.
                </>
              )}
            </DialogDescription>
          </DialogHeader>

          {selectedRide && (
            <div className="py-4">
              <SeatSelection
                availableSeats={selectedRide.availableSeats}
                price={selectedRide.price}
                onSeatChange={handleSeatChange}
              />
            </div>
          )}

          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setBookingDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleConfirmBooking}>Confirm Booking</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
