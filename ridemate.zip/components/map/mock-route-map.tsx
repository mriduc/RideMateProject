"use client"

import { useEffect, useRef } from "react"
import { cn } from "@/lib/utils"

interface MockRouteMapProps {
  startLocation: string
  endLocation: string
  className?: string
  interactive?: boolean
  showControls?: boolean
}

export default function MockRouteMap({
  startLocation,
  endLocation,
  className,
  interactive = true,
  showControls = true,
}: MockRouteMapProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  // Draw a simple route visualization on canvas
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const width = canvas.width
    const height = canvas.height

    // Clear canvas
    ctx.clearRect(0, 0, width, height)

    // Background
    ctx.fillStyle = "#f8fafc" // Light gray background
    ctx.fillRect(0, 0, width, height)

    // Draw grid lines
    ctx.strokeStyle = "#e2e8f0"
    ctx.lineWidth = 1

    // Horizontal grid lines
    for (let y = 20; y < height; y += 40) {
      ctx.beginPath()
      ctx.moveTo(0, y)
      ctx.lineTo(width, y)
      ctx.stroke()
    }

    // Vertical grid lines
    for (let x = 20; x < width; x += 40) {
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, height)
      ctx.stroke()
    }

    // Generate deterministic points based on location strings
    const getPointFromString = (str: string): [number, number] => {
      // Simple hash function to get a number from a string
      let hash = 0
      for (let i = 0; i < str.length; i++) {
        hash = (hash << 5) - hash + str.charCodeAt(i)
        hash |= 0 // Convert to 32bit integer
      }

      // Use the hash to generate x, y coordinates within the canvas
      const x = (Math.abs(hash) % 70) + 15
      const y = (Math.abs(hash >> 8) % 70) + 15

      return [x * (width / 100), y * (height / 100)]
    }

    const startPoint = getPointFromString(startLocation)
    const endPoint = getPointFromString(endLocation)

    // Ensure points are not too close
    if (Math.abs(startPoint[0] - endPoint[0]) < width * 0.2 && Math.abs(startPoint[1] - endPoint[1]) < height * 0.2) {
      endPoint[0] = (endPoint[0] + width * 0.3) % width
      endPoint[1] = (endPoint[1] + height * 0.3) % height
    }

    // Draw route line with curve
    const controlPoint = [
      (startPoint[0] + endPoint[0]) / 2 + (Math.random() - 0.5) * 50,
      (startPoint[1] + endPoint[1]) / 2 + (Math.random() - 0.5) * 50,
    ]

    ctx.beginPath()
    ctx.moveTo(startPoint[0], startPoint[1])
    ctx.quadraticCurveTo(controlPoint[0], controlPoint[1], endPoint[0], endPoint[1])
    ctx.strokeStyle = "#4ade80" // Green line
    ctx.lineWidth = 3
    ctx.stroke()

    // Draw start point
    ctx.beginPath()
    ctx.arc(startPoint[0], startPoint[1], 8, 0, Math.PI * 2)
    ctx.fillStyle = "#22c55e" // Green
    ctx.fill()
    ctx.strokeStyle = "#ffffff"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw end point
    ctx.beginPath()
    ctx.arc(endPoint[0], endPoint[1], 8, 0, Math.PI * 2)
    ctx.fillStyle = "#ef4444" // Red
    ctx.fill()
    ctx.strokeStyle = "#ffffff"
    ctx.lineWidth = 2
    ctx.stroke()

    // Add location labels
    ctx.font = "12px Arial"
    ctx.fillStyle = "#0f172a"
    ctx.textAlign = "center"

    // Start location label
    ctx.fillText(
      startLocation.length > 15 ? startLocation.substring(0, 15) + "..." : startLocation,
      startPoint[0],
      startPoint[1] - 15,
    )

    // End location label
    ctx.fillText(
      endLocation.length > 15 ? endLocation.substring(0, 15) + "..." : endLocation,
      endPoint[0],
      endPoint[1] - 15,
    )

    // Add controls if requested
    if (showControls) {
      // Zoom controls
      ctx.fillStyle = "#ffffff"
      ctx.strokeStyle = "#cbd5e1"
      ctx.lineWidth = 1

      // Zoom in button
      ctx.beginPath()
      ctx.rect(width - 40, 20, 30, 30)
      ctx.fill()
      ctx.stroke()

      // Zoom in icon
      ctx.beginPath()
      ctx.moveTo(width - 32, 35)
      ctx.lineTo(width - 18, 35)
      ctx.moveTo(width - 25, 28)
      ctx.lineTo(width - 25, 42)
      ctx.strokeStyle = "#64748b"
      ctx.lineWidth = 2
      ctx.stroke()

      // Zoom out button
      ctx.beginPath()
      ctx.rect(width - 40, 55, 30, 30)
      ctx.fillStyle = "#ffffff"
      ctx.strokeStyle = "#cbd5e1"
      ctx.lineWidth = 1
      ctx.fill()
      ctx.stroke()

      // Zoom out icon
      ctx.beginPath()
      ctx.moveTo(width - 32, 70)
      ctx.lineTo(width - 18, 70)
      ctx.strokeStyle = "#64748b"
      ctx.lineWidth = 2
      ctx.stroke()
    }
  }, [startLocation, endLocation, showControls])

  return (
    <div className={cn("relative rounded-lg border border-border overflow-hidden", className)}>
      <canvas
        ref={canvasRef}
        width={600}
        height={300}
        className="w-full h-full"
        style={{ touchAction: interactive ? "auto" : "none" }}
      />
    </div>
  )
}
