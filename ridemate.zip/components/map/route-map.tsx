"use client"

import { useEffect, useRef, useState } from "react"
import mapboxgl from "mapbox-gl"
import "mapbox-gl/dist/mapbox-gl.css"
import { cn } from "@/lib/utils"

// This would normally come from an environment variable
// For demo purposes, we're using a public token with restricted usage
const MAPBOX_TOKEN = "pk.eyJ1IjoiZXhhbXBsZXVzZXIiLCJhIjoiY2xvNXE0bWN1MDJ1YzJrcGR5ZDFkaHl4aiJ9.xfPaA-3XVZ-KLYwSt_bLVg"

// Initialize mapbox
mapboxgl.accessToken = MAPBOX_TOKEN

interface RouteMapProps {
  startLocation: string
  endLocation: string
  className?: string
  interactive?: boolean
  showControls?: boolean
}

export default function RouteMap({
  startLocation,
  endLocation,
  className,
  interactive = true,
  showControls = true,
}: RouteMapProps) {
  const mapContainer = useRef<HTMLDivElement>(null)
  const map = useRef<mapboxgl.Map | null>(null)
  const [mapLoaded, setMapLoaded] = useState(false)

  // Convert location strings to coordinates (in a real app, this would use a geocoding API)
  const getCoordinates = (location: string) => {
    // This is a simplified mock implementation
    // In a real app, you would use Mapbox Geocoding API or similar
    const mockCoordinates: Record<string, [number, number]> = {
      "New York": [-74.006, 40.7128],
      "Los Angeles": [-118.2437, 34.0522],
      Chicago: [-87.6298, 41.8781],
      Houston: [-95.3698, 29.7604],
      Phoenix: [-112.074, 33.4484],
      Philadelphia: [-75.1652, 39.9526],
      "San Antonio": [-98.4936, 29.4241],
      "San Diego": [-117.1611, 32.7157],
      Dallas: [-96.7969, 32.7767],
      "San Jose": [-121.8863, 37.3382],
      "San Francisco": [-122.4194, 37.7749],
      Seattle: [-122.3321, 47.6062],
      Boston: [-71.0589, 42.3601],
      Miami: [-80.1918, 25.7617],
      Denver: [-104.9903, 39.7392],
      "Las Vegas": [-115.1398, 36.1699],
    }

    // Default to a random location near the US center if not found
    const defaultLng = -98 + (Math.random() * 10 - 5)
    const defaultLat = 39 + (Math.random() * 6 - 3)

    // Check if we have mock coordinates for this location name
    // In a real app, you would do proper geocoding here
    for (const [key, value] of Object.entries(mockCoordinates)) {
      if (location.toLowerCase().includes(key.toLowerCase())) {
        return value
      }
    }

    return [defaultLng, defaultLat]
  }

  useEffect(() => {
    if (!mapContainer.current || map.current) return

    // Initialize map
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: "mapbox://styles/mapbox/streets-v12",
      center: [-98.5795, 39.8283], // Center of US
      zoom: 3,
      interactive: interactive,
    })

    // Add navigation controls if requested
    if (showControls) {
      map.current.addControl(new mapboxgl.NavigationControl(), "top-right")
    }

    // Set loaded state when map is ready
    map.current.on("load", () => {
      setMapLoaded(true)
    })

    // Cleanup on unmount
    return () => {
      if (map.current) {
        map.current.remove()
        map.current = null
      }
    }
  }, [interactive, showControls])

  // Update map when locations change
  useEffect(() => {
    if (!mapLoaded || !map.current) return

    // Get coordinates for start and end locations
    const startCoords = getCoordinates(startLocation)
    const endCoords = getCoordinates(endLocation)

    // Add source for route line
    if (!map.current.getSource("route")) {
      map.current.addSource("route", {
        type: "geojson",
        data: {
          type: "Feature",
          properties: {},
          geometry: {
            type: "LineString",
            coordinates: [startCoords, endCoords],
          },
        },
      })

      // Add route line layer
      map.current.addLayer({
        id: "route",
        type: "line",
        source: "route",
        layout: {
          "line-join": "round",
          "line-cap": "round",
        },
        paint: {
          "line-color": "#4ade80",
          "line-width": 4,
          "line-opacity": 0.8,
        },
      })
    } else {
      // Update existing route
      map.current.getSource("route").setData({
        type: "Feature",
        properties: {},
        geometry: {
          type: "LineString",
          coordinates: [startCoords, endCoords],
        },
      })
    }

    // Add markers for start and end points if they don't exist
    if (!map.current.getLayer("start-point")) {
      map.current.addSource("start-point", {
        type: "geojson",
        data: {
          type: "Feature",
          properties: {},
          geometry: {
            type: "Point",
            coordinates: startCoords,
          },
        },
      })

      map.current.addLayer({
        id: "start-point",
        type: "circle",
        source: "start-point",
        paint: {
          "circle-radius": 8,
          "circle-color": "#22c55e",
          "circle-stroke-width": 2,
          "circle-stroke-color": "#ffffff",
        },
      })
    } else {
      // Update existing start marker
      map.current.getSource("start-point").setData({
        type: "Feature",
        properties: {},
        geometry: {
          type: "Point",
          coordinates: startCoords,
        },
      })
    }

    if (!map.current.getLayer("end-point")) {
      map.current.addSource("end-point", {
        type: "geojson",
        data: {
          type: "Feature",
          properties: {},
          geometry: {
            type: "Point",
            coordinates: endCoords,
          },
        },
      })

      map.current.addLayer({
        id: "end-point",
        type: "circle",
        source: "end-point",
        paint: {
          "circle-radius": 8,
          "circle-color": "#ef4444",
          "circle-stroke-width": 2,
          "circle-stroke-color": "#ffffff",
        },
      })
    } else {
      // Update existing end marker
      map.current.getSource("end-point").setData({
        type: "Feature",
        properties: {},
        geometry: {
          type: "Point",
          coordinates: endCoords,
        },
      })
    }

    // Fit map to show both points with padding
    const bounds = new mapboxgl.LngLatBounds()
    bounds.extend(startCoords)
    bounds.extend(endCoords)

    map.current.fitBounds(bounds, {
      padding: 80,
      maxZoom: 12,
      duration: 1000,
    })
  }, [mapLoaded, startLocation, endLocation])

  return (
    <div ref={mapContainer} className={cn("h-64 w-full rounded-lg border border-border overflow-hidden", className)} />
  )
}
