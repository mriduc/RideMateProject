"use client"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import MockRouteMap from "./mock-route-map"
import { MapPin } from "lucide-react"

interface MockDetailedMapDialogProps {
  isOpen: boolean
  onClose: () => void
  startLocation: string
  endLocation: string
  driverName: string
}

export default function MockDetailedMapDialog({
  isOpen,
  onClose,
  startLocation,
  endLocation,
  driverName,
}: MockDetailedMapDialogProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[700px] p-0 overflow-hidden">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle>Route Details</DialogTitle>
        </DialogHeader>
        <div className="p-6 space-y-6">
          <MockRouteMap startLocation={startLocation} endLocation={endLocation} className="h-[400px] w-full" />

          <div className="grid gap-4">
            <div className="flex items-start gap-3">
              <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center mt-0.5">
                <MapPin className="h-4 w-4 text-green-600" />
              </div>
              <div>
                <p className="font-medium">Pickup Location</p>
                <p className="text-muted-foreground">{startLocation}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="h-8 w-8 rounded-full bg-red-100 flex items-center justify-center mt-0.5">
                <MapPin className="h-4 w-4 text-red-600" />
              </div>
              <div>
                <p className="font-medium">Drop-off Location</p>
                <p className="text-muted-foreground">{endLocation}</p>
              </div>
            </div>
          </div>

          <div className="text-sm text-muted-foreground">
            <p>
              This is the planned route for your ride with {driverName}. The actual route may vary slightly based on
              traffic conditions and driver preference.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
