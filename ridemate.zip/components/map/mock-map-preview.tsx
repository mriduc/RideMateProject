"use client"
import MockRouteMap from "./mock-route-map"
import { cn } from "@/lib/utils"

interface MockMapPreviewProps {
  startLocation: string
  endLocation: string
  className?: string
  onClick?: () => void
}

export default function MockMapPreview({ startLocation, endLocation, className, onClick }: MockMapPreviewProps) {
  return (
    <div className={cn("relative cursor-pointer group", className)} onClick={onClick}>
      <MockRouteMap
        startLocation={startLocation}
        endLocation={endLocation}
        className="h-32 transition-all"
        interactive={false}
        showControls={false}
      />
      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all flex items-center justify-center">
        <div className="bg-white/80 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-medium opacity-0 group-hover:opacity-100 transition-opacity">
          View route
        </div>
      </div>
    </div>
  )
}
