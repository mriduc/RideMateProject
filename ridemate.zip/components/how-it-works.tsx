import { Calendar, MapPin, Users } from "lucide-react"

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="w-full py-12 md:py-24 bg-muted/50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">How RideMate Works</h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl">
              Finding or offering a ride is simple and straightforward with our platform.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 md:grid-cols-3 md:gap-12">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-green-100 text-green-700">
              <MapPin className="h-6 w-6" />
            </div>
            <h3 className="text-xl font-bold">Enter Your Route</h3>
            <p className="text-muted-foreground">Tell us where you're starting from and where you're headed.</p>
          </div>
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-green-100 text-green-700">
              <Calendar className="h-6 w-6" />
            </div>
            <h3 className="text-xl font-bold">Choose Your Date</h3>
            <p className="text-muted-foreground">Select when you plan to travel to find matching rides.</p>
          </div>
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-green-100 text-green-700">
              <Users className="h-6 w-6" />
            </div>
            <h3 className="text-xl font-bold">Connect & Travel</h3>
            <p className="text-muted-foreground">
              Book your seat or welcome passengers and enjoy the journey together.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
