import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Car, Clock, DollarSign, Users } from "lucide-react"
import HeroSection from "@/components/hero-section"
import HowItWorks from "@/components/how-it-works"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center gap-2">
            <Car className="h-6 w-6" />
            <span className="text-xl font-bold">RideMate</span>
          </Link>
          <nav className="hidden md:flex gap-6">
            <Link href="/" className="text-sm font-medium hover:underline underline-offset-4">
              Home
            </Link>
            <Link href="#how-it-works" className="text-sm font-medium hover:underline underline-offset-4">
              How It Works
            </Link>
          </nav>
          <div className="flex gap-4">
            <Link href="/find-ride">
              <Button>Find a Ride</Button>
            </Link>
            <Link href="/offer-ride" className="hidden md:block">
              <Button variant="outline">Offer a Ride</Button>
            </Link>
            <Link href="/my-rides" className="hidden md:block">
              <Button variant="outline">My Rides</Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <HeroSection />
        <div className="container px-4 py-12 md:px-6 md:py-24">
          <div className="grid gap-6 md:grid-cols-3 md:gap-12">
            <div className="flex flex-col items-center text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-100 text-green-600 mb-4">
                <DollarSign className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold">Save Money</h3>
              <p className="text-muted-foreground mt-2">
                Split travel costs and save on gas, parking, and vehicle maintenance.
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100 text-blue-600 mb-4">
                <Users className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold">Meet People</h3>
              <p className="text-muted-foreground mt-2">
                Connect with like-minded travelers and make your commute more social.
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-amber-100 text-amber-600 mb-4">
                <Clock className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold">Reduce Emissions</h3>
              <p className="text-muted-foreground mt-2">
                Help the environment by reducing the number of vehicles on the road.
              </p>
            </div>
          </div>
        </div>
        <HowItWorks />
      </main>
      <Footer />
    </div>
  )
}
