import type React from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Car } from "lucide-react"
import Footer from "@/components/footer"

export default function MyRidesLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center gap-2">
            <Car className="h-6 w-6" />
            <span className="text-xl font-bold">RideMate</span>
          </Link>
          <nav className="hidden md:flex gap-6">
            <Link href="/" className="text-sm font-medium hover:underline underline-offset-4">
              Home
            </Link>
            <Link href="/find-ride" className="text-sm font-medium hover:underline underline-offset-4">
              Find a Ride
            </Link>
            <Link href="/my-rides" className="text-sm font-medium hover:underline underline-offset-4">
              My Rides
            </Link>
          </nav>
          <div className="flex gap-4">
            <Link href="/find-ride">
              <Button variant="outline">Find a Ride</Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  )
}
