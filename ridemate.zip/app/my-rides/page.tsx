"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { type BookedRide, cancelBookedRide, getBookedRides } from "@/lib/storage"
import { Calendar, Car, Clock, MapPin, Users } from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import MockMapPreview from "@/components/map/mock-map-preview"
import MockDetailedMapDialog from "@/components/map/mock-detailed-map-dialog"

export default function MyRidesPage() {
  const [rides, setRides] = useState<BookedRide[]>([])
  const [activeTab, setActiveTab] = useState("upcoming")
  const [selectedRide, setSelectedRide] = useState<BookedRide | null>(null)
  const [mapDialogOpen, setMapDialogOpen] = useState(false)

  useEffect(() => {
    // Load rides from local storage
    const storedRides = getBookedRides()
    setRides(storedRides)
  }, [])

  const handleCancelRide = (rideId: string) => {
    cancelBookedRide(rideId)
    // Update the state to reflect the cancellation
    setRides(rides.map((ride) => (ride.id === rideId ? { ...ride, status: "cancelled" } : ride)))
  }

  const upcomingRides = rides.filter((ride) => ride.status === "confirmed")
  const pastRides = rides.filter((ride) => ride.status === "completed" || ride.status === "cancelled")

  const openMapDialog = (ride: BookedRide) => {
    setSelectedRide(ride)
    setMapDialogOpen(true)
  }

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <div className="mx-auto max-w-4xl">
        <h1 className="text-3xl font-bold tracking-tight mb-6">My Rides</h1>

        {rides.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center p-6 text-center">
              <div className="rounded-full bg-muted p-3 mb-4">
                <Car className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-medium mb-2">No rides yet</h3>
              <p className="text-muted-foreground mb-4">
                You haven't booked any rides yet. Start by finding a ride that matches your travel plans.
              </p>
              <Link href="/find-ride">
                <Button>Find a Ride</Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <Tabs defaultValue="upcoming" onValueChange={setActiveTab}>
            <TabsList className="mb-6">
              <TabsTrigger value="upcoming">Upcoming Rides</TabsTrigger>
              <TabsTrigger value="past">Past Rides</TabsTrigger>
            </TabsList>

            <TabsContent value="upcoming">
              {upcomingRides.length === 0 ? (
                <Card>
                  <CardContent className="p-6 text-center">
                    <p className="text-muted-foreground">No upcoming rides.</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {upcomingRides.map((ride) => (
                    <Card key={ride.id}>
                      <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row gap-4">
                          <MockMapPreview
                            startLocation={ride.startLocation}
                            endLocation={ride.endLocation}
                            className="md:w-1/3"
                            onClick={() => openMapDialog(ride)}
                          />

                          <div className="flex-1 space-y-4">
                            <div className="flex justify-between items-start">
                              <h3 className="font-medium text-lg">Ride with {ride.driverName}</h3>
                              <Badge variant="outline" className="bg-green-50">
                                Confirmed
                              </Badge>
                            </div>

                            <div className="grid gap-2">
                              <div className="flex items-start gap-2">
                                <MapPin className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                                <div>
                                  <p className="text-sm font-medium">From</p>
                                  <p className="text-sm text-muted-foreground">{ride.startLocation}</p>
                                </div>
                              </div>
                              <div className="flex items-start gap-2">
                                <MapPin className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                                <div>
                                  <p className="text-sm font-medium">To</p>
                                  <p className="text-sm text-muted-foreground">{ride.endLocation}</p>
                                </div>
                              </div>
                            </div>

                            <div className="flex flex-wrap gap-4">
                              <div className="flex items-center gap-2">
                                <Calendar className="h-4 w-4 text-muted-foreground" />
                                <span className="text-sm">{ride.date}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Clock className="h-4 w-4 text-muted-foreground" />
                                <span className="text-sm">{ride.time}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Users className="h-4 w-4 text-muted-foreground" />
                                <span className="text-sm">{ride.seats} seat(s)</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Car className="h-4 w-4 text-muted-foreground" />
                                <span className="text-sm">{ride.carType}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="bg-muted/50 px-6 py-3 flex justify-between">
                        <p className="text-sm font-medium">₹{ride.totalAmount.toFixed(2)}</p>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="outline" size="sm">
                              Cancel Ride
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Cancel this ride?</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to cancel your ride from {ride.startLocation} to{" "}
                                {ride.endLocation} on {ride.date}? This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Keep Booking</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => handleCancelRide(ride.id)}
                                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                              >
                                Cancel Ride
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="past">
              {pastRides.length === 0 ? (
                <Card>
                  <CardContent className="p-6 text-center">
                    <p className="text-muted-foreground">No past rides.</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {pastRides.map((ride) => (
                    <Card key={ride.id}>
                      <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row gap-4">
                          <MockMapPreview
                            startLocation={ride.startLocation}
                            endLocation={ride.endLocation}
                            className="md:w-1/3"
                            onClick={() => openMapDialog(ride)}
                          />

                          <div className="flex-1 space-y-4">
                            <div className="flex justify-between items-start">
                              <h3 className="font-medium text-lg">Ride with {ride.driverName}</h3>
                              <Badge
                                variant="outline"
                                className={ride.status === "completed" ? "bg-blue-50" : "bg-red-50"}
                              >
                                {ride.status === "completed" ? "Completed" : "Cancelled"}
                              </Badge>
                            </div>

                            <div className="grid gap-2">
                              <div className="flex items-start gap-2">
                                <MapPin className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                                <div>
                                  <p className="text-sm font-medium">From</p>
                                  <p className="text-sm text-muted-foreground">{ride.startLocation}</p>
                                </div>
                              </div>
                              <div className="flex items-start gap-2">
                                <MapPin className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                                <div>
                                  <p className="text-sm font-medium">To</p>
                                  <p className="text-sm text-muted-foreground">{ride.endLocation}</p>
                                </div>
                              </div>
                            </div>

                            <div className="flex flex-wrap gap-4">
                              <div className="flex items-center gap-2">
                                <Calendar className="h-4 w-4 text-muted-foreground" />
                                <span className="text-sm">{ride.date}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Clock className="h-4 w-4 text-muted-foreground" />
                                <span className="text-sm">{ride.time}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Users className="h-4 w-4 text-muted-foreground" />
                                <span className="text-sm">{ride.seats} seat(s)</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="bg-muted/50 px-6 py-3">
                        <p className="text-sm font-medium">₹{ride.totalAmount.toFixed(2)}</p>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        )}
      </div>

      {selectedRide && (
        <MockDetailedMapDialog
          isOpen={mapDialogOpen}
          onClose={() => setMapDialogOpen(false)}
          startLocation={selectedRide.startLocation}
          endLocation={selectedRide.endLocation}
          driverName={selectedRide.driverName}
        />
      )}
    </div>
  )
}
