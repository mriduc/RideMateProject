"use client"

import { useEffect, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { type BookedRide, getBookedRides } from "@/lib/storage"
import BookingConfirmation from "@/components/booking/booking-confirmation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function BookingConfirmationPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const bookingId = searchParams.get("id")

  const [booking, setBooking] = useState<BookedRide | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!bookingId) {
      router.push("/find-ride")
      return
    }

    // Get the booking from local storage
    const rides = getBookedRides()
    const foundBooking = rides.find((ride) => ride.id === bookingId)

    if (foundBooking) {
      setBooking(foundBooking)
    }

    setLoading(false)
  }, [bookingId, router])

  if (loading) {
    return (
      <div className="container flex items-center justify-center min-h-[70vh]">
        <div className="text-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p>Loading booking details...</p>
        </div>
      </div>
    )
  }

  if (!booking) {
    return (
      <div className="container px-4 py-12 md:px-6">
        <Card className="max-w-md mx-auto">
          <CardContent className="p-6 text-center">
            <h2 className="text-xl font-bold mb-2">Booking Not Found</h2>
            <p className="text-muted-foreground mb-4">
              We couldn't find the booking you're looking for. It may have been cancelled or doesn't exist.
            </p>
            <Link href="/find-ride">
              <Button>Find a Ride</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <BookingConfirmation booking={booking} />
    </div>
  )
}
