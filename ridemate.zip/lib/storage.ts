// Local storage keys
export const STORAGE_KEYS = {
  BOOKED_RIDES: "ridemate-booked-rides",
  USER_PREFERENCES: "ridemate-user-preferences",
  USER_PROFILE: "ridemate-user-profile",
}

// Type definitions
export interface BookedRide {
  id: string
  rideId: number
  driverName: string
  driverRating: number
  startLocation: string
  endLocation: string
  date: string
  time: string
  price: number
  seats: number
  totalAmount: number
  status: "confirmed" | "completed" | "cancelled"
  bookingDate: string
  carType: string
}

export interface UserPreferences {
  preferredPaymentMethod?: string
  notificationsEnabled?: boolean
  darkMode?: boolean
}

export interface UserProfile {
  name?: string
  email?: string
  phone?: string
}

// Get booked rides from local storage
export function getBookedRides(): BookedRide[] {
  if (typeof window === "undefined") return []

  const storedRides = localStorage.getItem(STORAGE_KEYS.BOOKED_RIDES)
  return storedRides ? JSON.parse(storedRides) : []
}

// Save a new booked ride
export function saveBookedRide(ride: BookedRide): void {
  if (typeof window === "undefined") return

  const rides = getBookedRides()
  rides.push(ride)
  localStorage.setItem(STORAGE_KEYS.BOOKED_RIDES, JSON.stringify(rides))
}

// Update a booked ride
export function updateBookedRide(updatedRide: BookedRide): void {
  if (typeof window === "undefined") return

  const rides = getBookedRides()
  const index = rides.findIndex((ride) => ride.id === updatedRide.id)

  if (index !== -1) {
    rides[index] = updatedRide
    localStorage.setItem(STORAGE_KEYS.BOOKED_RIDES, JSON.stringify(rides))
  }
}

// Cancel a booked ride
export function cancelBookedRide(rideId: string): void {
  if (typeof window === "undefined") return

  const rides = getBookedRides()
  const index = rides.findIndex((ride) => ride.id === rideId)

  if (index !== -1) {
    rides[index].status = "cancelled"
    localStorage.setItem(STORAGE_KEYS.BOOKED_RIDES, JSON.stringify(rides))
  }
}

// Get user preferences
export function getUserPreferences(): UserPreferences {
  if (typeof window === "undefined") return {}

  const preferences = localStorage.getItem(STORAGE_KEYS.USER_PREFERENCES)
  return preferences
    ? JSON.parse(preferences)
    : {
        preferredPaymentMethod: "card",
        notificationsEnabled: true,
        darkMode: false,
      }
}

// Save user preferences
export function saveUserPreferences(preferences: UserPreferences): void {
  if (typeof window === "undefined") return

  localStorage.setItem(STORAGE_KEYS.USER_PREFERENCES, JSON.stringify(preferences))
}

// Get user profile
export function getUserProfile(): UserProfile {
  if (typeof window === "undefined") return {}

  const profile = localStorage.getItem(STORAGE_KEYS.USER_PROFILE)
  return profile ? JSON.parse(profile) : {}
}

// Save user profile
export function saveUserProfile(profile: UserProfile): void {
  if (typeof window === "undefined") return

  localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile))
}

// Generate a unique ID for bookings
export function generateBookingId(): string {
  return "bk-" + Date.now().toString(36) + Math.random().toString(36).substring(2, 5)
}
